#version 430
in vec2 texCoords;

uniform sampler2D moleculesIdTex;
uniform sampler2D ssaoIdTex;

layout(location = 0) out vec4 out_color;

void main(void)
{
  vec4 c0 = texture(moleculesIdTex, texCoords);
  vec4 c1 = texture(ssaoIdTex, texCoords);
  
  gl_FragDepth = c0.r;
  //out_color = vec4(gl_FragDepth, gl_FragDepth, gl_FragDepth, 1.0); 
  out_color = vec4(c1.rgb, c0.b); 
}
