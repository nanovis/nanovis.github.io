#version 430

in vec2 texCoords;

uniform sampler2D colorTex;
uniform sampler2D viewPosTex;
uniform float amount;
uniform vec2 size;

layout(location = 0) out vec4 out_col;

void main(void)
{
	float step = 1.0 / (size.x);

	vec4 texel, color = vec4(0.0);
	int i;
	float w, sum = 0.0;

	const float depthThreshold = 0.0001;

	if (amount == 0)
	{
		color = texture(colorTex, texCoords);
		sum = 1.0;
	}
	else
	{
		int iAmount = int((amount) + 1.0);
		float currentDepth = texture(viewPosTex, texCoords).z;
		for (i = -iAmount; i <= iAmount; i++)
		{
			float sampleDepth = texture(viewPosTex, texCoords + vec2(i * step, 0.0)).z;
			if (abs(currentDepth - sampleDepth) < depthThreshold) {
				texel = texture(colorTex, texCoords + vec2(i * step, 0.0));
				w = exp(-pow(i / amount * 1.5, 2.0));
				//w = 1.0;
				color += texel * w;
				sum += w;
			}
		}
	}

	out_col = color / sum;
	//gl_FragData[0] = vec4(1.0, 0.3, 1.0, 1.0);
}
