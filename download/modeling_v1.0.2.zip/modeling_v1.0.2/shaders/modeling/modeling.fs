#version 430

in vec4 fs_color;
in vec4 fs_info;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_info;

void main(void)
{
    out_color = fs_color;
	out_info = fs_info;
	
    //gl_FragColor = vec4(0.0, gl_FragCoord.z, 0.0, 1.0);
	//gl_FragColor = vec4(gl_FragDepth * 100000, 0.0, 0.0, 1.0);
}
