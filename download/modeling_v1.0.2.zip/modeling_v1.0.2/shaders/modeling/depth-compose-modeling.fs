#version 430
in vec2 texCoords;

uniform sampler2D layer0;
uniform sampler2D layer0d;
uniform sampler2D layer1;
uniform sampler2D layer1d;
uniform sampler2D layer2; 
uniform sampler2D layer2d;
uniform sampler2D layer3;
uniform sampler2D layer3a;

uniform sampler2D layerIds;

uniform int drawAlpha;
uniform int drawSelections;
uniform int useModelingDepth;

layout(location = 0) out vec4 fragColor;
layout(location = 1) out vec4 fragGlobalId;
layout(location = 2) out vec4 fragGlobalIdCol;

layout(std430) buffer;
layout(binding = 1) buffer INPUT1 {
  vec4 ProteinInstanceInfo[];
};

uint wang_hash(uint seed)
{
    seed = (seed ^ 61) ^ (seed >> 16);
    seed *= 9;
    seed = seed ^ (seed >> 4);
    seed *= 0x27d4eb2d;
    seed = seed ^ (seed >> 15);
    return seed;
}

float rand(uint value)
{
    return float(wang_hash(value)) * (1.0 / 4294967296.0);
}

void main()
{
  vec2 texCoord = texCoords;
  int instanceId = int(texture(layerIds, texCoord).r);
  //ids[1] = int(texture(layer1Ids, texCoord).r);
  
  float depth = 1.0;

  //~ if the IDs of current pixels are -1, then this pixel is a background (no rendered object)
  if (instanceId < 0) // && (ids[1] < 0))
  {
    //~ purple
    fragColor = vec4(1.0, 0.0, 1.0, 1.0);
    depth = 1.0;
    gl_FragDepth = depth;
    fragGlobalId = vec4(float(-1),float(-1),float(-1), 1.0);
    fragGlobalIdCol = vec4(0, 0, 0, 1);
    //return;
    discard;
  }

  vec4 colors[5];
  vec4 depths[3];
  // molecules->textures()[0]
  colors[0] = texture2D(layer0, texCoord);
  depths[0] = texture2D(layer0d, texCoord);
  // modeling->textures()[0]
  colors[1] = texture2D(layer1, texCoord);
  depths[1] = texture2D(layer1d, texCoord);
  // selections->textures()[0]
  colors[2] = texture2D(layer2, texCoord);
  depths[2] = texture2D(layer2d, texCoord);
  // moleculesAlpha->textures()[0]  
  colors[3] = texture2D(layer3, texCoord);
  // moleculesAlpha->textures()[6] // (fragPosClip.z, gl_FragDepth, alpha)
  colors[4] = texture2D(layer3a, texCoord);
  
  float d0r = depths[0].r;
  float d1r = depths[1].r;
  
  //~ TODO: actually do the blending of all the colors
  // (not taking just the last one)
  vec4 white = vec4(1,1,1,1);
  vec4 c0 = colors[0];
  vec4 c1 = colors[1];
  vec4 c2 = colors[2];
  vec4 c3 = colors[3];
  vec4 c4 = colors[4];
	
	
  // merging transparent instances
  vec4 c_ = c0;
  if(drawAlpha == 1) {
    float alpha = 1.0 - c4.b;
	float d = c4.g;
	
    if(alpha < 1.0 && alpha > 0.0 && d0r > d) {
      c_ = vec4(c0.rgb * alpha + c3.rgb * (1.0 - alpha), 1.0);  
    }
  }
  
  // modeling rendering
  if ((useModelingDepth == 0 && c1.w > 0) || d1r < d0r) {
    c_ = c1;
  }
  
  // selections rendering
  if (drawSelections == 1 && c2.rgb != vec3(0.0, 0.0, 0.0)) {
	  c_ = c2;
  }
  
  fragColor = c_;
  
  int finalFragId = instanceId;
  fragGlobalId = vec4(float(finalFragId), float(finalFragId), float(finalFragId), 1.0);
  fragGlobalIdCol = vec4(1.0, 1.0, 0.0, 1.0); // RandomColors[finalFragId];
  
  depth = depths[0].r;
  
  return;
  
  //dof
  float _focus = 0.99;
  float _dof = 0.3;
     
  float _depth = depth;
  
  if (depth == 1)
  {
      _depth = 1.0;
  }
  else if (abs(_depth - _focus) < _dof)
  {
      _depth = abs(_depth - _focus) / _dof;
  }
  else
  {
    _depth = 0.0;
  }  
    
  
  float amount = 1.0;
  
  vec4 sam;
  vec4 accum = vec4(0.0);
  float sum = 0.0;
  
  vec2 offset = vec2(0,0);
  
  for (uint i = 0; i < 500; i++)
  {
    offset = (-1.0 + 2.0 * vec2(rand(81*i+0), rand(81*i+13))) * 0.01 * amount * (_depth);
    sam = texture2D(layer0, texCoord.st + offset);
    accum += sam;
    sum++;  
  }
  accum /= sum;



  /*if (depth == 1)
    fragColor = vec4(1,0,0,1);
  else*/
    fragColor = accum;
}
