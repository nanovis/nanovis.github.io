#version 430

in GSOUTPUT
{
  vec2 uv;
  vec3 viewPos;
	vec4 clipPos;
  float radius;
  vec4 color;
  flat int instanceId;
  flat int atomId;
  float currentScale;
} INPUT;

uniform float Scale;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform int transparent;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_normal;
layout(location = 2) out vec4 out_viewPos;
layout(location = 3) out vec4 out_instanceId;
layout(location = 4) out vec4 out_atomId;
layout(location = 5) out vec4 out_globalId;
layout(location = 6) out vec4 out_depth;

layout (depth_greater) out float gl_FragDepth;

layout(std430) buffer;
layout(binding = 1) buffer INPUT1 {
  vec4 ProteinInstanceInfo[];
};

void main(void)
{
  if(transparent == 1 && ProteinInstanceInfo[INPUT.instanceId].z == 0.0) discard;
  if(transparent == 0 && ProteinInstanceInfo[INPUT.instanceId].z > 0.0) discard;
  
  float lensqr = dot(INPUT.uv, INPUT.uv);
  if (lensqr > 1.0) discard;

  float z = sqrt(1.0 - lensqr);

  vec3 normal = vec3(INPUT.uv.x, INPUT.uv.y, z);
  normal = normalize(normal);
  vec3 normalOut = normal * 0.5 + 0.5;

  vec3 fragViewPos = INPUT.viewPos;
  fragViewPos.z += INPUT.radius * Scale * sqrt(1.0 - lensqr);

  float offset = 1 - z;
  vec4 fragPosClip = INPUT.clipPos - projectionMatrix[2] * INPUT.radius * INPUT.currentScale * offset;

  // Viewport transformation according to
	// https://www.khronos.org/opengl/wiki/Vertex_Post-Processing
	gl_FragDepth =
		fragPosClip.z / fragPosClip.w *
		(gl_DepthRange.far - gl_DepthRange.near) * 0.5 +
		(gl_DepthRange.near + gl_DepthRange.far) * 0.5;

  // vec4 fragPosClip = projectionMatrix * vec4(fragViewPos, 1.0);
  // vec3 fragPosNDC = fragPosClip.xyz / fragPosClip.w;
  // float n = gl_DepthRange.near;
  // float f = gl_DepthRange.far;
  // float fragPosDepth = ((f - n) * fragPosNDC.z / 2.0) + ((f + n) / 2.0);
  // gl_FragDepth = fragPosDepth;

  //out_color = vec4(fragPosClip.z, fragPosClip.z, fragPosClip.z, 1.0);
  //out_color = vec4(INPUT.color.rgb, ProteinInstanceInfo[INPUT.instanceId].z);
  out_color = vec4(ProteinInstanceInfo[INPUT.instanceId].z, 0.0, 0.0, 1.0);
  out_normal = vec4(normalOut, 1.0);
  out_viewPos = vec4(fragViewPos.x, fragViewPos.y, fragViewPos.z, 1.0); // view space position buffer, for ssao
  // out_instanceId = vec4(float(INPUT.instanceId), 0, 0, 1.0);
  int renderingType = 0; // 0 = proteins
  out_instanceId = vec4(float(INPUT.instanceId), float(renderingType), 0, 1.0);
  out_atomId = vec4(float(INPUT.atomId), 0, 0, 1.0);
  out_globalId = vec4(0, 0, 0, 1);  
  
  out_depth = vec4(fragPosClip.z, gl_FragDepth, 1.0 - ProteinInstanceInfo[INPUT.instanceId].z, 1.0);
 
}
