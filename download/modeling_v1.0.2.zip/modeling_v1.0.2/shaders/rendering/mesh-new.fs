#version 460
in vec4 pos3D;
in vec3 light, outNormal, eye, v;
in vec4 outColor;
in flat int drawID;
in flat int globalObjectID;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_globalID;

void main(void)
{
  vec3 halfV = normalize(light - v);
  vec3 toFresnel = normalize(eye);
  vec3 n = normalize(outNormal.xyz);

  float nDotL = max(dot(n, halfV), 0.0);
  float fresnel = pow(max(dot(n, toFresnel), 0.0), 0.5);
  fresnel = clamp(pow(1.0 - fresnel, 1.0), 0.0, 1.0) * 0.65;

  vec4 color;
  if (drawID == 0)
  {
    color.rgb = vec3(0.8, 0.65, 0.65);
  }
  else {
    color.rgb = vec3(0.8, 0.01, 0.01);
  }


  //diffuse
  color.rgb = mix(vec3(0.0, 0.02, 0.1), color.rgb, max(0.1, nDotL));
  color.rgb = mix(vec3(0.0, 0.02, 0.15), color.rgb, max(0.1, nDotL));
  //specular
  color.rgb = mix(color.rgb, vec3(1.0, 1.0, 1.0), clamp(pow(nDotL, 160.0) * 1.7, 0.0, 1.0));

  color.rgb += vec3(fresnel * 0.8);
  
  
  out_color = vec4(color.rgb, 1.0);
  
  //out_color = vec4(color.rgb, 0.5);
  out_globalID = vec4(float(globalObjectID), float(globalObjectID), float(globalObjectID), 1.0);
}
