#version 430

in GSOUTPUT
{
	vec2 uv;
	vec3 viewPos;
	vec4 clipPos;
	vec3 color;
	float radius;
	flat int instanceId;
	flat int atomId;
} INPUT;

uniform float Scale;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform int ssaoEnabled;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_normal;
layout(location = 2) out vec4 out_viewPos;
layout(location = 3) out int out_instanceId;
layout(location = 4) out int out_atomId;
layout(location = 5) out int out_globalId;

// conservative depth extension for performance
layout (depth_greater) out float gl_FragDepth;

void main(void)
{
	float lensqr = dot(INPUT.uv, INPUT.uv);
	if (lensqr > 1.0)
		discard;

	float z = sqrt(1.0 - lensqr);

	// compute normal
	vec3 normal = vec3(INPUT.uv.x, INPUT.uv.y, z);
	normal = normal * 0.5 + 0.5;

	vec3 fragViewPos = INPUT.viewPos;
	fragViewPos.z += INPUT.radius * Scale * z;

	// adjust depth
	float offset = 1 - z;
	vec4 fragPosClip = INPUT.clipPos - projectionMatrix[2] * INPUT.radius * Scale * offset;

	// Viewport transformation according to
	// https://www.khronos.org/opengl/wiki/Vertex_Post-Processing
	gl_FragDepth =
		fragPosClip.z / fragPosClip.w *
		(gl_DepthRange.far - gl_DepthRange.near) * 0.5 +
		(gl_DepthRange.near + gl_DepthRange.far) * 0.5;

	// texture writes
	out_instanceId = INPUT.instanceId;
	out_atomId = INPUT.atomId;
	out_viewPos = vec4(INPUT.viewPos, INPUT.radius);
    out_color = vec4(INPUT.color, 1.0);
	out_color = vec4(normal, 1.0);
  out_globalId = 0;

	if(ssaoEnabled == 1)
	{
		out_normal = vec4(normal, 1.0); // for SSAO
		out_viewPos = vec4(fragViewPos.x, fragViewPos.y, fragViewPos.z, 1.0); // for SSAO
	}
}
