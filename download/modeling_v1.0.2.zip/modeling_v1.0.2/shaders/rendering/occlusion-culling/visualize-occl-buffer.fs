#version 430
in vec2 texCoords;

uniform int windowWidth;
uniform int windowHeight;
uniform int bufferSize;

layout(std430) buffer;
layout(binding = 0) readonly buffer INPUT0 {
  int ProteinInstanceOcclusionBuffer[];
};

out vec4 out_color;

void main()
{
  int sz = 2;
  vec2 pixelCoords = texCoords * vec2(windowWidth, windowHeight);
  int index = (windowWidth / sz) * (int(pixelCoords.y) / sz) + (int(pixelCoords.x) /sz);
  // int index = int(pixelCoords.x);

  if (index >= bufferSize)
  {
    discard;
  }

  int occlVal = ProteinInstanceOcclusionBuffer[index];

  vec3 col = (occlVal == 0) ? vec3(1, 0, 0) : vec3(0, 1, 0);

  // out_color = vec4(1, 0, 1, 1);
  // out_color = vec4(texCoords.x, texCoords.y, 0, 1);
  out_color = vec4(col, 1);
}
