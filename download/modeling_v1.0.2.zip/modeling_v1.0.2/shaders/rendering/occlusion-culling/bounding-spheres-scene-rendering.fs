#version 430
layout(early_fragment_tests) in;
in flat int instanceID;

layout(std430) buffer;
layout(binding = 3) buffer INPUT3 {
  int ProteinInstanceOcclusionBuffer[];
};

void main(void)
{
  ProteinInstanceOcclusionBuffer[instanceID] = 1;
}
