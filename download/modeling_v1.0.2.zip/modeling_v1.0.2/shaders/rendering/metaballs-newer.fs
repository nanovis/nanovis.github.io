#version 430
in vec3 center;
in vec3 offset;
in float radius;
in vec4 eyePosition;
in float depth;
in float doOffsetFade;

uniform float offsetFade;
uniform mat4 pm;
uniform mat4 mvm;
uniform int globalID; //~ ID from scene graph
uniform float scale;

layout(location = 0) out vec4 out_normal;
layout(location = 1) out vec4 out_color;
layout(location = 2) out vec4 out_depth;
layout(location = 3) out vec4 out_eyePos;
layout(location = 4) out vec4 out_globalId;

void main(void)
{
	// distance from sphere center to current fragment position
	float distanceSquared = dot(offset.xy, offset.xy);
	if (distanceSquared > 1.0) {
		 discard;
	 }

	// compute the correct depth
	float z = sqrt(1.0 - distanceSquared);
	float depthCorrected =  depth + z * radius * (1.0 - pow(offsetFade * doOffsetFade, 0.1));

	vec4 depthVec = pm * vec4(0,0,depthCorrected,1);

	// compute depth in normal device coordinates
	float ndcDepth = depthVec.z / depthVec.w;

	gl_FragDepth = ((gl_DepthRange.diff * ndcDepth) + gl_DepthRange.near + gl_DepthRange.far) / 2.0;
  //gl_FragDepth = 0.9;

	vec3 normal_viewSpace = vec3(offset.xy, z);
	normal_viewSpace = normalize(normal_viewSpace);

	out_normal = vec4(vec3(0.5 + 0.5 * normal_viewSpace), 1.0);
	out_color = vec4(0, 0, 1, 1);
 	out_depth = vec4(ndcDepth, ndcDepth,ndcDepth, 1.0);
	out_eyePos = vec4(eyePosition.xyz, 1);
  out_globalId = vec4(float(globalID), float(globalID), float(globalID), 1.0);
}
