#version 430
in vec2 texCoords;

uniform sampler2D layer0;
uniform sampler2D layer0d;
uniform sampler2D layer1;
uniform sampler2D layer1a;

uniform sampler2D layerIds;

uniform int drawAlpha;

layout(location = 0) out vec4 fragColor;
layout(location = 1) out vec4 fragGlobalId;
layout(location = 2) out vec4 fragGlobalIdCol;

uint wang_hash(uint seed)
{
    seed = (seed ^ 61) ^ (seed >> 16);
    seed *= 9;
    seed = seed ^ (seed >> 4);
    seed *= 0x27d4eb2d;
    seed = seed ^ (seed >> 15);
    return seed;
}

float rand(uint value)
{
    return float(wang_hash(value)) * (1.0 / 4294967296.0);
}

void main()
{
  vec2 texCoord = texCoords;
  int instanceId = int(texture(layerIds, texCoord).r);
  //ids[1] = int(texture(layer1Ids, texCoord).r);
  
  float depth = 1.0;

  //~ if the IDs of current pixels are -1, then this pixel is a background (no rendered object)
  if (instanceId < 0) // && (ids[1] < 0))
  {
    //~ purple
    fragColor = vec4(1.0, 0.0, 1.0, 1.0);
    depth = 1.0;
    gl_FragDepth = depth;
    fragGlobalId = vec4(float(-1),float(-1),float(-1), 1.0);
    fragGlobalIdCol = vec4(0, 0, 0, 1);
    //return;
    discard;
  }

  vec4 colors[3];
  vec4 depths[1];
  // molecules->textures()[0]
  colors[0] = texture2D(layer0, texCoord);
  depths[0] = texture2D(layer0d, texCoord);
  // moleculesAlpha->textures()[0]
  colors[1] = texture2D(layer1, texCoord);
  // moleculesAlpha->textures()[6]
  colors[2] = texture2D(layer1a, texCoord);
  
  float d0r = depths[0].r;
  depth = d0r;
  
  //~ TODO: actually do the blending of all the colors
  // (not taking just the last one)
  vec4 white = vec4(1,1,1,1);
  vec4 c0 = colors[0];
  vec4 c1 = colors[1];
  vec4 c2 = colors[2];
  
  // merging transparent instances  
  vec4 c_ = c0;
  if(drawAlpha == 1) {
    float alpha = 1.0 - c2.b;
	  float d = c2.g;
	
    if(alpha < 1.0 && alpha > 0.0 && d0r > d) {
      c_ = vec4(c0.rgb * alpha + c1.rgb * (1.0 - alpha), 1.0);
      depth = d;  
    }

    fragColor = vec4(alpha, 0, 0, 1);
  }
  
  fragColor = c_;

  //gl_FragDepth = depth;
  
  
  int finalFragId = instanceId;
  fragGlobalId = vec4(float(finalFragId), float(finalFragId), float(finalFragId), 1.0);
  fragGlobalIdCol = vec4(1.0, 1.0, 0.0, 1.0); // RandomColors[finalFragId];  
}
