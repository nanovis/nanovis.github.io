#version 430
in vec2 texCoords;

uniform sampler2D inputTex;
uniform int channel;
layout(location = 0) out vec4 out_color;

void main(void)
{
  float value;
  if(channel==1)
	value= (texture(inputTex, texCoords)).r;
  else if(channel==2)
	value= (texture(inputTex, texCoords)).g;
 else if(channel==3)
	value= (texture(inputTex, texCoords)).b;
  else
       value= (texture(inputTex, texCoords)).a;

  out_color = vec4(value ,value ,value ,1.0) ;
}
