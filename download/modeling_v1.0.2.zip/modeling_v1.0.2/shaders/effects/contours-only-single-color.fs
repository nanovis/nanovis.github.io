#version 430
in vec2 texCoords;

uniform vec4 contourColor;
uniform sampler2D instanceIdTex; //~ also this will be used to get the contours

layout(location = 0) out vec4 output_col;
layout(location = 1) out vec4 out_globalId;

void main(void)
{
  // vec4 col = texture(colorTex, texCoords);
  vec4 col = contourColor;

  // vec2 resolution = textureSize(colorTex, 0);
  vec2 resolution = textureSize(instanceIdTex, 0);

  vec2 pixelPos = texCoords * resolution;
  float wStep = 1.0 / resolution.x;
  float hStep = 1.0 / resolution.y;

  // int X = int(texture(instanceIdTex, texCoords).r);
  // int R = int(texture(instanceIdTex, texCoords + vec2(wStep, 0)).r);
  // int L = int(texture(instanceIdTex, texCoords + vec2(-wStep, 0)).r);
  // int T = int(texture(instanceIdTex, texCoords + vec2(0, hStep)).r);
  // int B = int(texture(instanceIdTex, texCoords + vec2(0, -hStep)).r);

  int X = int(texture(instanceIdTex, texCoords).g);
  int R = int(texture(instanceIdTex, texCoords + vec2(wStep, 0)).g);
  int L = int(texture(instanceIdTex, texCoords + vec2(-wStep, 0)).g);
  int T = int(texture(instanceIdTex, texCoords + vec2(0, hStep)).g);
  int B = int(texture(instanceIdTex, texCoords + vec2(0, -hStep)).g);

  vec4 finalColor;
  if ( (X == R) && (X == L) && (X == T) && (X == B) )
  { //~ current pixel is NOT on the edge
    //finalColor = bgCol;
    // finalColor = bgColor;
    //finalColor = stencilCol;
    // finalColor = vec4(1,0,0,1);
    // finalColor = bgColor;
    discard; //~ maybe this way it's more correct...
  }
  else
  { //~ current pixel lies on the edge
    // finalColor = mix(vec4(0,0,0,1), col, 0.8);
    // float alpha = 0.25;
    float alpha = 0.8;
    finalColor = vec4(col.rgb, alpha);
    //finalColor = vec4(1, 0, 0, 1);
  }

  output_col = finalColor;
  out_globalId = vec4(0, 0, 0, 1);
  // output_col = col;
  // output_col = bgCol;
  // output_col = stencilCol;
  //output_col = texture(instanceIdStencilTex, texCoords);
}
