#version 430
in vec2 texCoords;

uniform sampler2D normalTex;
uniform isampler2D atomIdTex;
uniform isampler2D instanceIdTex;
uniform sampler2D viewPosTex;
uniform isampler2D globalIdTex;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_normal;
layout(location = 2) out vec4 out_viewPos;
layout(location = 3) out vec4 out_instanceId;
layout(location = 4) out vec4 out_atomId;
layout(location = 5) out vec4 out_globalId;

void main(void)
{
  vec4 normal = texture(normalTex, texCoords);
  vec4 viewPos = texture(viewPosTex, texCoords);
  int atomId = texture(atomIdTex, texCoords).r;
  int instanceId = texture(instanceIdTex, texCoords).r;
  int globalId = texture(globalIdTex, texCoords).r;

  // out_color = vec4(1, 0, 0, 1);
  out_normal = normal;
  out_viewPos = viewPos;
  out_instanceId = vec4(instanceId, 0, 0, 1);
  out_atomId = vec4(atomId, 0, 0, 1);
  out_globalId = vec4(globalId, 0, 0, 1);
}
