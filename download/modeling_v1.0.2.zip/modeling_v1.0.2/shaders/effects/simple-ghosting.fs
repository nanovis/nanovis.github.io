#version 430
in vec2 texCoords;

uniform vec4 bgColor;
uniform sampler2D solidPartsTex;
uniform sampler2D ghostedPartsTex;
uniform sampler2D solidPartsIDsTex;

out vec4 out_color;

void main()
{
  vec4 solidCol = texture(solidPartsTex, texCoords);
  vec4 ghostedCol = texture(ghostedPartsTex, texCoords);
  float fragmentId = texture(solidPartsIDsTex, texCoords).x;
  //vec4 white = vec4(1,1,1,1);
  vec4 white = bgColor;
  //solidCol.a = 0.5;
  ghostedCol.a = 0.3;

  vec4 c = vec4(ghostedCol.rgb * ghostedCol.a + white.rgb * (1.0 - ghostedCol.a),
                clamp(white.a + ghostedCol.a, 0.0, 1.0));
  if (fragmentId >= 0.0)
  {
    c = vec4(solidCol.rgb * solidCol.a + c.rgb * (1.0 - solidCol.a),
             clamp(c.a + solidCol.a, 0.0, 1.0));
  }

  // out_color = vec4(1, 0, 1, 1);
  out_color = c;
  //out_color = solidCol;
  // out_color = ghostedCol;
}
