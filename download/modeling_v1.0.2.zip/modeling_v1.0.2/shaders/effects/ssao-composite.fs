#version 430
in vec2 texCoords;

uniform sampler2D colorTex;
uniform sampler2D ssaoTex;

out vec4 out_color;

void main(void)
{
  vec4 col = texture(colorTex, texCoords);
  float occ = texture(ssaoTex, texCoords).r;
  out_color = vec4(occ * col.xyz, 1.0);
}
