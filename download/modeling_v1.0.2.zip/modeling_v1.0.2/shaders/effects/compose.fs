#version 430
in vec2 texCoords;

uniform sampler2D texture0;
uniform sampler2D texture1;
uniform sampler2D texture2;
uniform sampler2D texture3;

layout(location = 0) out vec4 out_color;

void main(void)
{
  vec4 texVal0 = texture(texture0, texCoords);
  vec4 texVal1 = texture(texture1, texCoords);
  vec4 texVal2 = texture(texture2, texCoords);
  vec4 texVal3 = texture(texture3, texCoords);

  //out_color = vec4(1.0, 0.5, 0.0, 1.0);
  //out_color = vec4(texCoords.x, texCoords.y, 0, 1);
  // out_color = vec4(texVal0.xyz, 1.0);
  out_color = vec4(texVal0.xyz * 0.4 + texVal1.xyz * 0.6, 1.0);
}
