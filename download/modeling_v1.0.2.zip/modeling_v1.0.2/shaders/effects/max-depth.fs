#version 430
flat in float depthValue;
// flat in vec4 distanceTransformVal; // TODO: needs to be made non-interpolating!!
// flat in vec4 viewPos;
// flat in int regionsId;
// flat in int regionsLevel;

// uniform mat4 projectionMatrix;

// const vec2 margins = vec2(0.2, 0.2);

layout(location = 0) out vec4 out_value;
// layout(location = 1) out vec4 out_viewSpacePos;
// layout(location = 2) out vec4 out_otherInfo;

/*
 based on scattering approach used in labeling algorithm
*/
void main(void)
{
  //if (distanceTransformVal.z < 0.0) discard;

  //~ Penalizing candidates placed close to borders
  // float bottom = min(margins.y, distanceTransformVal.y) / margins.y;
  // float top = min(margins.y, 1.0 - distanceTransformVal.y) / margins.y;
  // float vPenalty = min(bottom, top);
  // float left = min(margins.x, distanceTransformVal.x) / margins.x;
  // float right = min(margins.x, 1.0 - distanceTransformVal.x) / margins.x;
  // float hPenalty = min(left, right);

  // float mPenalty = min(vPenalty, hPenalty);

  //~ Prefer candidates closer to the camera
  // vec4 fragPosClip = projectionMatrix * vec4(viewPos.xyz, 1.0);
  // vec3 fragPosNDC = fragPosClip.xyz / fragPosClip.w;
  // //float n = gl_DepthRange.near;
  // //float f = gl_DepthRange.far;
  // float n = 0.01;
  // float f = 16.0;
  // //float fragPosDepth = ((f - n) * fragPosNDC.z / 2.0) + ((f + n) / 2.0);
  // float fragPosDepth = (fragPosNDC.z - n) / (f - n);

  //~ Outputs
  out_value = vec4(depthValue, depthValue, depthValue, 1.0);
  //out_value = vec4(0.5, 0, 0, 1.0);
  //out_viewSpacePos = viewPos;
  //out_otherInfo = vec4(regionsId, regionsLevel, distanceTransformVal.z, 1.0);
  //gl_FragDepth = 1.0 - distanceTransformVal.z * mPenalty; // what if distanceTransformVal.z is more than 1???
  // gl_FragDepth = 1.0 - distanceTransformVal.z * mPenalty * (1.0 - fragPosDepth); // what if distanceTransformVal.z is more than 1???
//  gl_FragDepth = 1.0 - depthValue;
  gl_FragDepth = depthValue;
  //gl_FragDepth = 1.0;
}
