#version 430
in vec2 texCoords;

uniform sampler2D layer0;
uniform sampler2D layer0d;
uniform sampler2D layer1;
uniform sampler2D layer1d;
uniform sampler2D layer2;
uniform sampler2D layer2d;

uniform sampler2D layer0Ids;
uniform sampler2D layer1Ids;
uniform sampler2D layer2Ids;

uniform float l0opacity;
uniform float l1opacity;
uniform float l2opacity;

uniform float membraneAlpha;

layout(std430) buffer;
layout(binding = 0) buffer INPUT0 {
  vec4 RandomColors[];
};

layout(location = 0) out vec4 fragColor;
layout(location = 1) out vec4 fragGlobalId;
layout(location = 2) out vec4 fragGlobalIdCol;


uint wang_hash(uint seed)
{
    seed = (seed ^ 61) ^ (seed >> 16);
    seed *= 9;
    seed = seed ^ (seed >> 4);
    seed *= 0x27d4eb2d;
    seed = seed ^ (seed >> 15);
    return seed;
}

float rand(uint value)
{
	return float(wang_hash(value)) * (1.0 / 4294967296.0);
}




void main()
{
  vec2 texCoord = texCoords;
  int ids[3];

  ids[0] = int(texture(layer0Ids, texCoord).r);
  ids[1] = int(texture(layer1Ids, texCoord).r);
  ids[2] = int(texture(layer2Ids, texCoord).r);

  float depth = 1.0;

  //~ if the IDs of current pixels are -1, then this pixel is a background (no rendered object)
  if ((ids[0] < 0) && (ids[1] < 0) && (ids[2] < 0))
  {
    //~ purple
    fragColor = vec4(1.0, 0.0, 1.0, 1.0);
    depth = 1.0;
    gl_FragDepth = depth;
    fragGlobalId = vec4(float(-1),float(-1),float(-1), 1.0);
    fragGlobalIdCol = vec4(0, 0, 0, 1);
    //return;
    discard;
  }

  vec4 colors[3];
  vec4 depths[3];
  colors[0] = texture2D(layer0, texCoord);
  depths[0] = texture2D(layer0d, texCoord);
  colors[1] = texture2D(layer1, texCoord);
  depths[1] = texture2D(layer1d, texCoord);
  colors[2] = texture2D(layer2, texCoord);
  depths[2] = texture2D(layer2d, texCoord);

  //~ debug
  // colors[1].a = 0.8;
  colors[1].a = membraneAlpha;
  //colors[1].a = 0.9;

  int first, second, third;
  if (depths[0].r >= depths[1].r && depths[0].r >= depths[2].r)
  {
    first = 0;
    if (depths[1].r > depths[2].r)
    {
      second = 1;
      third = 2;
    }
    else
    {
      second = 2;
      third = 1;
    }
  }
  if (depths[1].r >= depths[0].r && depths[1].r >= depths[2].r)
  {
    first = 1;
    if (depths[0].r > depths[2].r)
    {
      second = 0;
      third = 2;
    }
    else
    {
      second = 2;
      third = 0;
    }
  }
  if (depths[2].r >= depths[0].r && depths[2].r >= depths[1].r)
  {
    first = 2;
    if (depths[0].r > depths[1].r)
    {
      second = 0;
      third = 1;
    }
    else
    {
      second = 1;
      third = 0;
    }
  }

  //~ TODO: actually do the blending of all the colors
  // (not taking just the last one)
  vec4 white = vec4(0,0,0,1);
  vec4 c0 = colors[first];
  vec4 c1 = colors[second];
  vec4 c2 = colors[third];
  vec4 c_ = vec4(c0.rgb * c0.a + white.rgb * (1.0 - c0.a), clamp(white.a + c0.a, 0.0, 1.0));
       c_ = vec4(c1.rgb * c1.a + c_.rgb * (1.0 - c1.a), clamp(c_.a + c1.a, 0.0, 1.0));
       c_ = vec4(c2.rgb * c2.a + c_.rgb * (1.0 - c2.a), clamp(c_.a + c2.a, 0.0, 1.0));


  fragColor = c_;
  //fragColor = colors[third];
  //fragColor = colors[1];

  int finalFragId = ids[third];
  fragGlobalId = vec4(float(finalFragId), float(finalFragId), float(finalFragId), 1.0);
  fragGlobalIdCol = RandomColors[finalFragId];

  depth = depths[third].r;
  gl_FragDepth = depth;
  //return;
  
  depth = depths[0].r;
  //fragColor = vec4((1.0 - depth) * 99999.0, 0.0, 0.0, 1.0);
  gl_FragDepth = depth;
  ///if(gl_FragCoord.x < 1000) {
  //fragColor = vec4(depth * 10000000, 0.0, 0.0, 1.0);
  //fragColor = vec4((1.0 - depth) * 99999.0, 0.0, 0.0, 1.0);
  //return;  
  //}
  
  //dof
  depths[0] = texture2D(layer0d, vec2(0.5,0.5));
  depths[1] = texture2D(layer1d, vec2(0.5,0.5));
  depths[2] = texture2D(layer2d, vec2(0.5,0.5));  
  
  float _focus = //0.99;
					depths[third].r;
  float _dof = 0.01;     
  float _depth = depth;
  float _coc = 0.0;
  
  if (_depth == 1)
  {
	  _coc = 1.0;
  }
  else if (abs(_depth - _focus) < _dof)
  {
	  _coc = abs(_depth - _focus) / _dof;
  }
  else
  {
	_coc = 1.0;
  }  
    
  
  float amount = 1.0;
  
 
  vec2 offset = vec2(0,0);
  

  //average depth difference
  float samDD;
  float maxDD = 0.0;
  float accumDD = 0.0;
  float sumDD = 0.0;
  for (uint i = 0; i < 100; i++)
  {
	//vec2 rv = (-1.0 + 2.0 * vec2(rand(81*i+0), rand(81*i+13)));	
	float a = rand(81*i+0) * 2.0 * 3.141592654;
	float r = sqrt(rand(81*i+13));
	vec2 rv = vec2(r * cos(a), r * sin(a));
	
    offset = rv * 0.01 * amount * 2.0;

    vec4 samDD4 = texture2D(layer0d, texCoord.st + offset);    
	
	samDD = /*abs*/(_depth - samDD4.r);
	
    accumDD += samDD;
    sumDD++;
  }
  accumDD /= sumDD;
  
  accumDD = clamp(accumDD * 200.0, 0.0, 1.0);

  //fragColor = vec4(accumDD,0,0,1);return;
   
  vec4 sam;
  vec4 accum = vec4(0.0);
  float sum = 0.0;  
  for (uint i = 0; i < 100; i++)
  {
	//vec2 rv = (-1.0 + 2.0 * vec2(rand(81*i+0), rand(81*i+13)));	
	float a = rand(81*i+0) * 2.0 * 3.141592654;
	float r = sqrt(rand(81*i+13));
	vec2 rv = vec2(r * cos(a), r * sin(a));
	
    offset = rv * 0.01 * amount * (_coc + accumDD);

    sam = texture2D(layer0, texCoord.st + offset);    
		
    accum += sam;
    sum++;  
  }
  accum /= sum;

  /*if (depth == 1)
	fragColor = vec4(1,0,0,1);
  else*/
	fragColor = accum;

}
