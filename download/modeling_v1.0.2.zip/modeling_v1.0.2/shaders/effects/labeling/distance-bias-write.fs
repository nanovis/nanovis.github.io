#version 430
in float biasValue;
flat in int regionId;

layout(location = 0) out vec4 out_value;
layout(location = 1) out vec4 out_regionId;

void main(void)
{
  out_regionId = vec4(float(regionId), 0, 0, 1.0);
  out_value = vec4(biasValue, 0, 0, biasValue);
//  out_value = vec4(biasValue, 0, 0, biasValue);
  //~ making it so that if no bias is written then the pixel will be transparent (for debug view reasons)
}
