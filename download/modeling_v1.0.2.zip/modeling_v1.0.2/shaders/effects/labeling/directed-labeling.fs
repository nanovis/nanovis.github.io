#version 430
in vec2 texCoords;

uniform sampler2D instanceIdTex;
uniform int lipidsOffset;
uniform int fibersOffset;

layout(std430) buffer;
layout(binding = 0) buffer INPUT0 {
  vec4 ProteinInstanceInfo[];
};

layout(binding = 1) buffer INPUT1 {
  vec4 CapsidInstancesInfo[];
};

layout(binding = 2) buffer INPUT2 {
  vec4 InstanceLabelingInfo[];
};

//~ Color output is not used but it's here because you can't force floating point format on the default attachment
layout(location = 0) out vec4 color_output;
layout(location = 1) out vec4 metric_output;

void main(void)
{
  vec4 idvec = texture(instanceIdTex, texCoords);
  int instanceId = int(idvec.x);
  int renderingType = int(idvec.y);
  metric_output = vec4(0, 0, 0, 0);

  if (instanceId < 0.0) discard;
  int index = instanceId;
  // 0 = proteins, 1 = fibers, 2 = lipids
  if (renderingType == 1) index += fibersOffset;
  if (renderingType == 2) index += lipidsOffset;

  int typeId = int(ProteinInstanceInfo[instanceId].x);
  // int representative = int(InstanceLabelingInfo[instanceId].x);
  // int excluded = int(InstanceLabelingInfo[instanceId].y);
  // int directedLabelId = int(InstanceLabelingInfo[instanceId].z);
  int representative = int(InstanceLabelingInfo[index].x);
  int excluded = int(InstanceLabelingInfo[index].y);
  int directedLabelId = int(InstanceLabelingInfo[index].z);

  //~ if this instance is excluded, then we do not label it at all
  // if (excluded == 1) discard;

  //~ new idea:
  //directedLabelId = 0;
  int depthAwareCompartmentID = directedLabelId;
  int regionId = depthAwareCompartmentID;

  if (excluded == 1) regionId = -1;
  // if (depthAwareCompartmentID == 54) //~ polymer level
  // {
  //   regionId = int(CapsidInstancesInfo[instanceId - 16619].x) + 58; // need to be offset both index and regionid
  //   instanceId = int(CapsidInstancesInfo[instanceId].y);
  // }

  // metric_output = vec4(regionId, finalSeg, instanceId, 1.0);
  metric_output = vec4(regionId, 1, instanceId, 1.0);
}
