#version 430
in vec2 texCoords;

uniform sampler2D seedTex;
uniform float stepSize;
uniform float widthScale;
uniform float heightScale;

layout(location = 0) out vec4 out_value;

float scaleDistance(vec2 a, vec2 b, float widthScale, float heightScale)
{
  float dx = (b.x - a.x) * widthScale;
  //float dx = (b.x - a.x) / widthScale;
  float dy = (b.y - a.y) * heightScale;
	//float dy = (b.y - a.y) / heightScale;
	return sqrt(dx*dx + dy*dy);
}

void main(void)
{
  //float2 uv = i.uv * float2(512, 512);
  vec2 uv = texCoords;
  vec4 centralVal = texture(seedTex, uv);

  //centralVal = vec4(centralVal.z, centralVal.z, centralVal.z, 1.0);

  //out_value = centralVal;
  //return;
  // float4 centralVal = _SeedTexture[uv];

  // maybe this could be taken out of the shader?
  // float k = jumpDist * _StepSize;
  float k = stepSize / 512.0;
  vec2 offset[8] = {
    vec2(k, 0.0),
    vec2(-k, 0.0),
    vec2(0.0, k),
    vec2(0.0, -k),
    vec2(k, k),
    vec2(-k, -k),
    vec2(k, -k),
    vec2(-k, k)
  };

  for (int j = 0; j < 8; j++) {
    vec2 off = offset[j];
    vec4 val = texture(seedTex, uv + off); // this needs to sampled by (0,1) interval UV!!!
    //if (val.z >= 1.0) continue; // does this even work? precision...

    float d1 = centralVal.z;
    //float d2 = scaleDistance(i.uv, val.xy, _WidthScale, _HeightScale);
    float d2 = scaleDistance(uv, val.xy, widthScale, heightScale);
    //float d2 = distance(uv, val.xy);

    if (d1 > d2) {
      centralVal = vec4(val.xy, d2, val.w);
      //centralVal = vec4(val.xy, d2, val.w);
      //centralVal = vec4(d2, d2, d2, 1.0);
    }
  }
  //out_value = vec4(0, 0, centralVal.z, 1.0);
  out_value = centralVal;
}
