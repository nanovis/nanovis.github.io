#version 430
in vec2 texCoords;
in vec3 viewPos;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_id;

void main(void)
{
  out_id = vec4(0, 0, 0, 1);
  out_color = vec4(1, 0, 0, 1);
}
