#version 430
in vec2 texCoords;
in vec3 viewPos;
// in vec2 uv;
uniform sampler2D fontTexture;
uniform sampler2D fontStrokeTexture;
uniform sampler2D viewPosTex;
uniform bool depthTest;
uniform vec4 textColor;
uniform bool drawStroke;
uniform vec4 strokeColor;
uniform sampler2D regionsIdTex;
uniform int labelRegionId;
uniform int labelRegionLevel;
uniform float lineThickness;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_id;

void main(void)
{
  vec4 col = textColor;
  //vec4 col = vec4(1, 1, 1, 1);
  //vec4 col = vec4(0, 0, 0, 1);
  // if (depthTest)
  if (false)
  {
    vec2 sz = textureSize(viewPosTex, 0);
    vec2 uv = gl_FragCoord.xy / sz;
    vec4 sceneViewPos = texture(viewPosTex, uv);

    vec4 fragRegionIdVal = texture(regionsIdTex, uv);
    int fragLevel = int(fragRegionIdVal.g);

    //if (labelRegionId != int(fragRegionIdVal.r))
    //if ((labelRegionId != int(fragRegionIdVal.r)) && (fragLevel >= labelRegionLevel) && (labelRegionLevel == 0))
    if ((labelRegionId != int(fragRegionIdVal.r)))
    {
      //if (viewPos.z <= sceneViewPos.z) discard;
      if (viewPos.z <= sceneViewPos.z) col.w = min(col.w, 0.4);
    }
  }
  //vec2 fontTexSize = textureSize(fontTexture, 0);
  //vec2 offset = vec2(1.0 / fontTexSize.x, 1.0 / fontTexSize.y);
  //float shadowVal = texture(fontTexture, texCoords + offset).r;
//  float lineThickness = 30.0;
  // float wStep = lineThickness / fontTexSize.x;
  // float hStep = lineThickness / fontTexSize.y;
  // float R = texture(fontTexture, texCoords + vec2(wStep, 0)).r;
  // float L = texture(fontTexture, texCoords + vec2(-wStep, 0)).r;
  // float T = texture(fontTexture, texCoords + vec2(0, hStep)).r;
  // float B = texture(fontTexture, texCoords + vec2(0, -hStep)).r;

  float fontVal = texture(fontTexture, texCoords).r;
  //float fontVal = texture(fontStrokeTexture, texCoords).r;
  float fontStrokeVal = texture(fontStrokeTexture, texCoords).r;
  out_id = vec4(labelRegionId, 0, 0, fontVal);
  vec4 colFill = vec4(1, 1, 1, fontVal) * col;
  vec4 colStroke = vec4(1, 1, 1, fontStrokeVal) * strokeColor;

  if (drawStroke)
  {
    out_color = vec4(colStroke.rgb + (1.0f - colStroke.a) * colFill.rgb, colFill.a + colStroke.a);
  }
  else {
    out_color = colFill;
  }

  // out_color = vec4(colFill.rgb * colStroke.a + colStroke.rgb * colFill.a, 1);
  //out_color = vec4(colFill.rgb * colStroke.a + colStroke.rgb * colFill.a, fontVal);

  // out_color = vec4(colFill.rgb * (1.0f - colStroke.a) + colStroke.rgb, colFill.a);
  // out_color = vec4(colFill.rgb * (1.0f - colStroke.a) + colStroke.rgb, colFill.a);

  //out_color = vec4(colFill.rgb, colStroke.a);
  //out_color = colFill;
  // out_color = colStroke;

  //out_color = vec4(1, 1, 1, fontVal) * col;
  // out_color = vec4(0, 0, 0, fontStrokeVal) * out_color;


  //if (fontVal <= 0) out_color = vec4(1.0, 1.0, 0.0, 1.0);
  //out_color = vec4(1, 1, 1, 1) * col;
  //out_color = vec4(1, 1, 1, 1);
//  if ((fontVal < 1.0) && ((R > 0.5) || (L > 0.5) || (T > 0.5) || (B > 0.5))) out_color = vec4(black.xyz, fontVal);
//  if (fontVal < 1.0 && shadowVal > 0.0) out_color = white;
}
