#version 430
in vec2 texCoords;

uniform sampler2D depthCategoriesTex;
uniform sampler2D viewPosTex; // This is to debug the depth
uniform mat4 projectionMatrix;

layout(std430) buffer;
layout(binding = 0) buffer INPUT0 {
  vec4 RandomColors[];
};

// layout(binding = 1) buffer INPUT1 {
//   int RegionsDirectParentBuffer[];
// };

layout(location = 0) out vec4 color_output;

void main(void)
{
  vec2 resolution = textureSize(depthCategoriesTex, 0);
  vec4 pixelVal = texture(depthCategoriesTex, texCoords);
  vec4 viewPos = texture(viewPosTex, texCoords);
  int categoryValue = int(pixelVal.x);
  int instanceId = int(pixelVal.z);

  float wStep = 10.0 / resolution.x;
  float hStep = 10.0 / resolution.y;
  int R = int(texture(depthCategoriesTex, texCoords + vec2(wStep, 0)).x);
  int L = int(texture(depthCategoriesTex, texCoords + vec2(-wStep, 0)).x);
  int T = int(texture(depthCategoriesTex, texCoords + vec2(0, hStep)).x);
  int B = int(texture(depthCategoriesTex, texCoords + vec2(0, -hStep)).x);

  // int PR = RegionsDirectParentBuffer[R];
  // int PL = RegionsDirectParentBuffer[L];
  // int PT = RegionsDirectParentBuffer[T];
  // int PB = RegionsDirectParentBuffer[B];

  // if (PR == categoryValue) categoryValue = R;
  // if (PL == categoryValue) categoryValue = L;
  // if (PT == categoryValue) categoryValue = T;
  // if (PB == categoryValue) categoryValue = B;
  // if ( (P == R) || (P == L) || (P == T) || (P == B) )
  // {
  //   categoryValue = R;
  // }

  if (categoryValue >= 1000)
  {
    color_output = vec4(1.0, 1.0, 1.0, 1.0);
    return;
  }

  color_output = RandomColors[categoryValue];
  //color_output = RandomColors[instanceId];

  vec4 fragPosClip = projectionMatrix * vec4(viewPos.xyz, 1.0);
  vec3 fragPosNDC = fragPosClip.xyz / fragPosClip.w;
  float n = 0.01;
  float f = 16.0;
  //float fragPosDepth = ((f - n) * fragPosNDC.z / 2.0) + ((f + n) / 2.0);
  float fragPosDepth = (fragPosNDC.z - n) / (f - n);
  float d = fragPosDepth;

  //color_output = vec4(viewPos.x, viewPos.y, 1.0, 1.0);
  //color_output = vec4(d, d, d, 1.0);
}
