#version 430
in vec2 texCoords;

uniform sampler2D instanceIdTex;
// uniform int lipidsOffset;
// uniform int fibersOffset;

uniform int currentLevelId;

layout(std430) buffer;
// layout(binding = 0) buffer INPUT0 {
//   vec4 ProteinInstanceInfo[];
// };
//
// layout(binding = 1) buffer INPUT1 {
//   vec4 CapsidInstancesInfo[];
// };

layout(binding = 0) buffer INPUT0 {
  vec4 InstanceLabelingInfo[];
};

//~ Color output is not used but it's here because you can't force floating point format on the default attachment
layout(location = 0) out vec4 color_output;
layout(location = 1) out vec4 regions_output;

void main(void)
{
  vec4 idvec = texture(instanceIdTex, texCoords);
  int instanceId = int(idvec.x);
  int renderingType = int(idvec.y);
  color_output = vec4(1, 0, 0, 1);
  regions_output = vec4(-1, -1, -1, 1);

  if (instanceId < 0.0) discard;

   int directedLabelId = int(InstanceLabelingInfo[instanceId].z);
  //int directedLabelId = int(InstanceLabelingInfo[1234].z);

  // int regionId = currentLevelId;
  int regionId = directedLabelId;
  // int regionId = 123;

  //instanceId = 123;
  regions_output = vec4(instanceId, regionId, 0, 1.0); //~ the contour pass looks at .r coord and makes contour where they are different
}
