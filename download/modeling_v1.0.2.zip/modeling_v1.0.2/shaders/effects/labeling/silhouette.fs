#version 430
in vec2 texCoords;

uniform sampler2D regionsTex;

layout(location = 0) out vec4 out_value;

bool compareRegionIDs(vec4 X, vec4 R, vec4 L, vec4 T, vec4 B)
{
  if ( (X.r == R.r) && (X.r == L.r) && (X.r == T.r) && (X.r == B.r))
  {
    return true;
  }
  return false;
}

bool compareInstanceIDs(int level, vec4 X, vec4 R, vec4 L, vec4 T, vec4 B)
{
  if (level != 0) return true; //~ if the region is of higher level I don't want to compare instanceIDs

  if ( (X.b == R.b) && (X.b == L.b) && (X.b == T.b) && (X.b == B.b))
  {
    return true;
  }
  return false;
}

void main(void)
{
  vec2 resolution = textureSize(regionsTex, 0);

  float wStep = 1.0 / resolution.x;
  float hStep = 1.0 / resolution.y;

  vec4 X = texture(regionsTex, texCoords);
  vec4 R = texture(regionsTex, texCoords + vec2(wStep, 0));
  vec4 L = texture(regionsTex, texCoords + vec2(-wStep, 0));
  vec4 T = texture(regionsTex, texCoords + vec2(0, hStep));
  vec4 B = texture(regionsTex, texCoords + vec2(0, -hStep));

  int level = int(X.g);
  vec4 finalValue;
  if ( compareRegionIDs(X, R, L, T, B) && compareInstanceIDs(level, X, R, L, T, B))
  { //~ current pixel is NOT on the edge
    finalValue = vec4(0.0, 0.0, 1.0, 1.0);
  }
  else
  { //~ current pixel lies on the edge
    finalValue = vec4(texCoords, 0.0, 1.0);
  }

  out_value = finalValue;
}
