#version 430
//in vec2 texCoords;
in vec3 viewPos;

uniform vec4 boxColor;
uniform sampler2D viewPosTex;
uniform bool depthTest;
uniform sampler2D regionsIdTex;
uniform int labelRegionId;
uniform int labelRegionLevel;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_id;

void main(void)
{
  vec4 col = boxColor;
  if (depthTest)
  {
    vec2 sz = textureSize(viewPosTex, 0);
    vec2 uv = gl_FragCoord.xy / sz;
    vec4 sceneViewPos = texture(viewPosTex, uv);
    vec4 fragRegionIdVal = texture(regionsIdTex, uv);
    int fragLevel = int(fragRegionIdVal.g);

  //  if ((labelRegionId != int(fragRegionIdVal.r)) && (fragLevel >= labelRegionLevel) && (labelRegionLevel == 0))
    if ((labelRegionId != int(fragRegionIdVal.r)))
    {
      //if (viewPos.z <= sceneViewPos.z) discard;
      if (viewPos.z <= sceneViewPos.z) col.w = min(col.w, 0.35);
    }
  }

  vec4 textColor = vec4(col);
  out_color = textColor;
  out_id = vec4(labelRegionId, 0, 0, 1);
}
