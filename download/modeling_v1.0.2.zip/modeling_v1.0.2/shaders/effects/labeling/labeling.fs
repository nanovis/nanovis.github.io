#version 430
in vec2 texCoords;

uniform sampler2D instanceIdTex;
uniform sampler2D viewPosTex;

uniform float near;
uniform float far;
uniform int ingredientMaxDepth;

layout(std430) buffer;
layout(binding = 0) buffer INPUT0 {
  vec4 ProteinInstanceInfo[];
};

layout(binding = 1) buffer INPUT1 {
  int IngredientParents[];
};

layout(binding = 2) buffer INPUT2 {
  int IngredientDepths[];
};

layout(binding = 3) buffer INPUT3 {
  float DepthThresholds[];
};

layout(binding = 4) buffer INPUT4 {
  vec4 CapsidInstancesInfo[];
};

// layout(binding = 5) buffer INPUT5 {
//   vec4 ProteinInstanceInfo2[];
// };

//~ Color output is not used but it's here because you can't force floating point format on the default attachment
layout(location = 0) out vec4 color_output;
layout(location = 1) out vec4 metric_output;

void main(void)
{
  vec4 idvec = texture(instanceIdTex, texCoords);
  int instanceId = int(idvec.x);
  metric_output = vec4(0, 0, 0, 0);

  if (instanceId < 0.0) discard;

  int typeId = int(ProteinInstanceInfo[instanceId].x);
  //int representative = int(ProteinInstanceInfo2[instanceId].x);
  //int excluded = int(ProteinInstanceInfo2[instanceId].y);

  //~ if this instance is excluded, then we do not label it at all
//  if (excluded == 1) discard;

  // if (typeId == 39) //~ capsid
  // {
  //   vec4 capsidInfo = CapsidInstancesInfo[instanceId - 16619];
  //   capsidInfo.x; // pentamer or hexamer
  //   //instanceId = int(capsidInfo.y); // polymerID
  // }

  vec4 viewpos = texture(viewPosTex, texCoords);
  viewpos.z = -viewpos.z;

  int numOfDepthSegments = IngredientDepths[typeId];
  numOfDepthSegments += 1; //~ One more for the protein type level itself

  int finalSeg = 0;
  for (int k = 0; k < numOfDepthSegments; k++)
  {
    finalSeg = (viewpos.z < DepthThresholds[k]) ? finalSeg : k + 1;
  }
  if (viewpos.z >= DepthThresholds[numOfDepthSegments - 1]) finalSeg = numOfDepthSegments - 1;

  //finalSeg = 0;
  //if (typeId == 5) finalSeg = 0;
//  if (representative == 1) finalSeg = 0;

  int depthAwareCompartmentID = IngredientParents[typeId * (ingredientMaxDepth+1) + finalSeg];
  int regionId = depthAwareCompartmentID;
  if (depthAwareCompartmentID == 54) //~ polymer level
  {
    regionId = int(CapsidInstancesInfo[instanceId - 16619].x) + 58; // need to be offset both index and regionid
    instanceId = int(CapsidInstancesInfo[instanceId].y);
  }

  metric_output = vec4(regionId, finalSeg, instanceId, 1.0);
}
