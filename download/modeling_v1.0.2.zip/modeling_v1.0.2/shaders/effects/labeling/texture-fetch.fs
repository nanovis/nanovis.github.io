#version 430
flat in vec4 textureValue;

layout(location = 0) out vec4 out_dummy;
layout(location = 1) out vec4 out_value;

void main(void)
{
  out_value = vec4(textureValue.xyz, 1.0);
}
