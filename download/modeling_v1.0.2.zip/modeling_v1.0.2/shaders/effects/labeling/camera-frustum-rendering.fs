#version 430

uniform vec3 cameraColor;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_id;

void main(void)
{
  out_id = vec4(0, 0, 0, 1);
  out_color = vec4(cameraColor, 1);
}
