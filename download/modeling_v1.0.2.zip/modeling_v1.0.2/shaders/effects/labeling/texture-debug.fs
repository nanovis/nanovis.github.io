#version 430
in vec2 texCoords;

uniform sampler2D inputTex;

layout(location = 0) out vec4 out_color;

void main(void)
{
  vec4 color = texture(inputTex, texCoords);
  float d = color.z * 15;
  out_color = vec4(d, d, d, 1.0);
}
