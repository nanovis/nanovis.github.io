#version 430
uniform vec3 uColor;
uniform float uAlpha;

layout(location = 0) out vec4 out_color;

void main(void)
{
  //vec4(255.0 / 255.0, 247 / 255.0, 153 / 255.0)
  // out_color = vec4(255.0 / 255.0, 247 / 255.0, 153 / 255.0, 1.0);
  out_color = vec4(uColor, uAlpha);
  //out_color = vec4(1, 1, 0, 1);
}
