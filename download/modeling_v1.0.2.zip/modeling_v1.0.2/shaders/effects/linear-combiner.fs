#version 430
in vec2 texCoords;

uniform sampler2D colorTexA;
uniform sampler2D colorTexB;
uniform sampler2D globalIdTexA;
uniform sampler2D globalIdTexB;
uniform float uAlpha;

layout(location = 0) out vec4 out_color;
layout(location = 1) out vec4 out_globalId;

void main(void)
{
  vec4 colValA = texture(colorTexA, texCoords);
  vec4 colValB = texture(colorTexB, texCoords);
  int idValA = int(texture(globalIdTexA, texCoords).x);
  int idValB = int(texture(globalIdTexB, texCoords).x);

  int finalId = -1;
  if (idValA >= 0) {
    finalId = idValA;
  }
  if (idValB >= 0) {
    finalId = idValB; //~ this might cause problems later if we mix molecular rendering with meshes etc..
  }

  out_color = mix(colValA, colValB, uAlpha);
  if (uAlpha == 1.0)
  { //~ bit fake solution: when the transition is complete, only use the global id values from the final picture
    finalId = idValB;
  }
  out_globalId = vec4(finalId, 0, 0, 1);
}
