#version 430
in vec2 texCoords;

uniform sampler2D inputTex;

layout(location = 0) out vec4 out_color;

void main(void)
{
  out_color = texture(inputTex, texCoords);
}
