#version 430
//~
//~ This shader is only different from countour.fs
//~ by using isampler2D instead of sampler2D.
//~

in vec2 texCoords;

uniform sampler2D colorTex;
uniform isampler2D instanceIdTex;

layout(location = 0) out vec4 output_col;

void main(void)
{
  vec4 col = texture(colorTex, texCoords);
  //output_col = col;
  //return;

  vec2 resolution = textureSize(colorTex, 0);

  vec2 pixelPos = texCoords * resolution;
  float wStep = 1.0 / resolution.x;
  float hStep = 1.0 / resolution.y;

  int X = texture(instanceIdTex, texCoords).r;
  int R = texture(instanceIdTex, texCoords + vec2(wStep, 0)).r;
  int L = texture(instanceIdTex, texCoords + vec2(-wStep, 0)).r;
  int T = texture(instanceIdTex, texCoords + vec2(0, hStep)).r;
  int B = texture(instanceIdTex, texCoords + vec2(0, -hStep)).r;

  vec4 finalColor;
  if ( (X == R) && (X == L) && (X == T) && (X == B) )
  { //~ current pixel is NOT on the edge
    finalColor = col;
  }
  else
  { //~ current pixel lies on the edge
    finalColor = mix(vec4(0,0,0,1), col, 0.8);
  }

  output_col = finalColor;
  //output_col = col;
}
