# WebRenderer
Basic start project combining WebGPU, Dawn, ImGui and Emscripten. It can be built using VS (for desktop) or using the make file (for web deployment).

Tested with Chrome Canary 92.0.4496.0 with the `--enable-unsafe-webgpu` flag.

# Inspired by (and derived from) the following examples
- https://github.com/cwoffenden/hello-webgpu
- https://github.com/ocornut/imgui/tree/master/examples/example_emscripten_wgpu

# Libraries used
- GLFW3 for window manipulation
- https://github.com/DavidDurman/FlexiColorPicker (MIT)

# How to build
- Desktop: Open Visual Studio solution (tested 2019) and build. The output should be in `out/x64/Debug/`.
- Web: Open commandline and type `make`. The output should be in `out/web/`.

# Known issues:
- device lost when resizing window in the desktop mode
- CMake not yet working
